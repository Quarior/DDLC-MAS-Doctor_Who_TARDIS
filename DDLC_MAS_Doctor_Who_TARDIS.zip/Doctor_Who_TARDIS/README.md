# Doki Doki Literature Club: Monika After Story: Doctor Who TARDIS
You can find the original mod (DDLC: MAS) here: https://github.com/Monika-After-Story/MonikaModDev.

## Features
A submod to add a TARDIS on Doki Doki Literature Club: Monika After Story.

## Installation
1) Place this files in game\\submods\\Doctor_Who_TARDIS.
2) Open the game.
4) Done.

## Note
For the moment, the gift doesn't work, so it is disable. So I put a TARDIS already for Monika.

You need to have minimum 400 in relation to enter in the TARDIS.
